﻿using Performance_Specifications.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.Model
{
    public class ApplicationFiles
    {
        private string application;
        private string filepath;

        public static Object Lock = new Object();

        private SplitAndArrange split;
        public string _Application
        {
            get { return this.application; }
            set { this.application = value; }
        }

        public string FilePath
        {
            get { return this.filepath; }
            set { this.filepath = value; }
        }
        public ApplicationFiles(SplitAndArrange split,string dirname)
        {
            this.split = split;
            this.application = split.DataModel.Application;
            this.filepath = dirname + application + split.Date + ".txt";
        }

        public void StoreApplicationRecord()
        {
            lock (Lock)
            {
                File.AppendAllText(FilePath, split.Line + Environment.NewLine);
            }
        }
    }
}
