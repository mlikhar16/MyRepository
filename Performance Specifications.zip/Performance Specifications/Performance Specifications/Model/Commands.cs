﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Performance_Specifications.Model
{
    class Commands : ICommand
    {
        public event EventHandler CanExecuteChanged;

        private readonly Action<object> executeAction;
        private readonly Func<object, bool> canExecute;
        public bool CanExecute(object parameter)
        {
            return this.canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            this.executeAction(parameter);
        }

        public Commands(Action<object> executeAction,Func<object,bool> canExecute)
        {
            this.executeAction = executeAction;
            this.canExecute = canExecute;
        }
    }
}
