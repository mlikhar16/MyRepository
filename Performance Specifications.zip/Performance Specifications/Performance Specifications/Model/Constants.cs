﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.Model
{
    class Constants
    {
        public static string BaseDir = "C:\\Temp\\";
        public static string filterRegex = "*Logging(PerformanceLoggingUtil)*milliseconds*";
        public static string logValidationString = "Logfile";
        public static string NotApplicable = "NA";
        public static List<string> seconds = new List<string>() {"s","sec", "secs", "second","seconds"};
        public static List<string> minutes = new List<string>() { "min", "mins", "minute", "minutes" };
        public static List<string> milliseconds = new List<string>() { "ms", "msec","millisec", "msecs","millisecs", "millisecond", "milliseconds" };
        public static string Success = "pack://application:,,,/img/green-square.png";
        public static string Failure = "pack://application:,,,/img/red-square.png";
        public static string SuccessText = "Success";
        public static string FailureText = "Failure";
        public static string NA = "pack://application:,,,/img/yellow-square.png";
        public static string logextension = ".log";
        public static string logfilter = "Log files (.log)|*.log";
        public static string csvextension = ".csv";
        public static string csvfilter = "CSV files (.csv)|*.csv";
        public static string excelextension = ".xlsx";
        public static string excelfilter = "Excel files (.xlsx)|*.xlsx";
        public static string sheet = "PerformanceSpecifications";
    }
}
