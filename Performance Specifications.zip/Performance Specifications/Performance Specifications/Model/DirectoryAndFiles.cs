﻿using Performance_Specifications.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.Model
{

    public class DirectoryAndFiles:INotifyPropertyChanged, IDirectoryAndFiles
    {
        private string dirname;
        private string inputfilename;
        private string outputfilename;
        private string inputfilepath;
        private string aliasNameforOutputFile ; 
        private string outputfilePath;
        private string date;

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChange([CallerMemberName] string property = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }
        public string DirectoryName
        {
            get { return this.dirname; }
            set
            {
                this.dirname = value;
                NotifyPropertyChange();
            }
        }
        public string InputFileName
        {
            get { return this.inputfilename; }
            set
            {
                this.inputfilename = value;
                NotifyPropertyChange();
            }
        }

        public string OutputFileName
        {
            get { return this.outputfilename; }
            set
            {
                this.outputfilename = value;
                NotifyPropertyChange();
            }
        }

        public string InputFilePath
        {
            get { return this.inputfilepath; }
            set
            {
                this.inputfilepath = value;
                NotifyPropertyChange();
            }
        }

        public string OutputFilePath
        {
            get { return this.outputfilePath; }
            set
            {
                this.outputfilePath = value;
                NotifyPropertyChange();
            }
        }
        
        public string Date
        {
            get { return this.date; }
            set
            {
                this.date = value;
                NotifyPropertyChange();
            }
        }

        public DirectoryAndFiles(string filepath,string alias)
        {
            this.inputfilepath = filepath;
            this.aliasNameforOutputFile = alias;
            GetInputFileName();
            GetDate();
            GetDirectoryName();
            GetOutputFileName();
            GetOutputFilePath();
        }

        public DirectoryAndFiles(string filepath, string alias,string dirname,
                                 string filename,string date)
        {
            this.inputfilepath = filepath;
            this.aliasNameforOutputFile = alias;
            this.dirname = dirname;
            this.inputfilename = filename;
            this.date = date;
            GetOutputFileName();
            GetOutputFilePath();
        }


        public void GetDate()
        {
            string line = System.IO.File.ReadLines(inputfilepath).Skip(0).Take(1).First();
            SplitAndArrange split = new SplitAndArrange(line);
            split.GetDate();
            this.date = split.Date;
        }

        public void GetInputFileName()
        {
            string[] path = this.inputfilepath.Split('\\');
            string[] logfile = path[path.Length - 1].Split('.');
            this.inputfilename = logfile[0];
        }

        public void GetOutputFileName()
        {
            this.outputfilename = this.inputfilename + this.aliasNameforOutputFile;
        }
        
        public void GetOutputFilePath()
        {
            this.outputfilePath = this.dirname + this.outputfilename + ".txt";
        }
        
        public void GetDirectoryName()
        {
            this.dirname = Constants.BaseDir + this.inputfilename + this.date + '\\';
        }
        public void CreateDirectory()
        {
            if (Directory.Exists(dirname))
                Directory.Delete(dirname,true);
            Directory.CreateDirectory(dirname);
        }

    }
}
