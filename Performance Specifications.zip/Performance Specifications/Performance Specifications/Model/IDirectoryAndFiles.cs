﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.Model
{
    public interface IDirectoryAndFiles
    {
        string DirectoryName { get; set; }
        string InputFileName { get; set; }
        string OutputFileName { get; set; }
        string InputFilePath { get; set; }
        string OutputFilePath { get; set; }
        string Date { get; set; }
        void GetDate();
        void GetOutputFilePath();
        void GetInputFileName();
        void GetDirectoryName();
        void CreateDirectory();
    }
}
