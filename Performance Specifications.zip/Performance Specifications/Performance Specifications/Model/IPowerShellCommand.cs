﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Management.Automation;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications
{
    public interface IPowerShellCommand
    {
        Collection<PSObject> RunPowerShellCommand();
    }
}
