﻿using Performance_Specifications.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.Model
{
    public interface IReadLogFile
    {
        int TotalEntries { get; set; }
        DirectoryAndFiles DF { get; set; }
        string FilePath { get; set; }
        void ReadAndFilter();
    }
}
