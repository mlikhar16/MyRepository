﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.Model
{
    public class LogFilter 
    {
        public static void ExecutePowerShellCommand(string filepath, List<string> filters)
        {
            Runspace runspace = RunspaceFactory.CreateRunspace();
            runspace.Open();
            Pipeline pipeline = runspace.CreatePipeline();
            string commandtext = GetCommand(filepath, filters);
            pipeline.Commands.AddScript(commandtext);
            Collection<PSObject> psObjs = pipeline.Invoke();
        }

        private static string GetCommand(string filepath,List<string> filters)
        {
            string commandtext = String.Format("Get-Content -Path \"{0}\" | Where-Object {{", filepath);
            for (int i = 0; i < filters.Count; i++)
            {
                if (i == filters.Count - 1)
                    commandtext += String.Format("($_ -like '*{0}*milliseconds')}}", filters[i]);
                else
                    commandtext += String.Format("($_ -like '*{0}*milliseconds') -or ", filters[i]);
            }
            return commandtext;
        }
    }
}
