﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.Model
{
    public class PerformanceSpecificationDataModel
    {

        /// <summary>
        /// Gets or sets the Time.
        /// </summary>
        /// <value>Time.</value>
        public string Time { get; set; }

        /// <summary>
        /// Gets or sets the Severity.
        /// </summary>
        /// <value>Severity.</value>
        public string Severity { get; set; }

        /// <summary>
        /// Gets or sets the Program Epic.
        /// </summary>
        /// <value>Program Epic.</value>
        public string Application { get; set; }

        /// <summary>
        /// Gets or sets the Performnce Requirement Id.
        /// </summary>
        /// <value>Performance Requirement Id.</value>
        public string PerfReqId { get; set; }

        /// <summary>
        /// Gets or sets the Description of Performance Specification.
        /// </summary>
        /// <value>Description.</value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Performance Specification Actual value.
        /// </summary>
        /// <value>Performance Specification.</value>
        public string ActualValue { get; set; }

        /// <summary>
        /// Gets or sets Performance Specification Validation value.
        /// </summary>
        /// <value>Performance Specification.</value>
        public string ValidationValue { get; set; }

        /// <summary>
        /// Gets or sets Performance Specification Validation Judgement.
        /// </summary>
        /// <value>Performance Specification.</value>
        public Uri Validation { get; set; }

    }
}
