﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Performance_Specifications.Model
{
    public class PerformanceSpecificationDataProvider:IItemsProvider<PerformanceSpecificationDataModel>,INotifyPropertyChanged
    {
        private readonly int _count;
        private readonly int _fetchDelay;
        private string filename;

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChange([CallerMemberName] string property = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PerformanceSpecificationDataModelProvider"/> class.
        /// </summary>
        /// <param name="count">The count.</param>
        /// <param name="fetchDelay">The fetch delay.</param>
        public PerformanceSpecificationDataProvider(int count, int fetchDelay,string filename)
        {
            _count = count;
            _fetchDelay = fetchDelay;
            this.filename = filename;
        }

        /// <summary>
        /// Fetches the total number of items available.
        /// </summary>
        /// <returns></returns>
        public int FetchCount()
        {
            Trace.WriteLine("FetchCount");
            Thread.Sleep(_fetchDelay);
            return _count;
        }

        public static IEnumerable<string> ReadLines(string path)
        {
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, 
                                   FileShare.ReadWrite, 0x1000, FileOptions.SequentialScan))
            using (var sr = new StreamReader(fs, Encoding.UTF8))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    yield return line;
                }
            }
        }

        /// <summary>
        /// Fetches a range of items.
        /// </summary>
        /// <param name="startIndex">The start index.</param>
        /// <param name="count">The number of items to fetch.</param>
        /// <returns></returns>
        public IList<PerformanceSpecificationDataModel> FetchRange(int startIndex, int count)
        {
            Trace.WriteLine("FetchRange: " + startIndex + "," + count);
            Thread.Sleep(_fetchDelay);
            string sep = "\t";
            IEnumerable<string> lines = ReadLines(this.filename).Skip(startIndex).Take(Math.Min(count,_count-startIndex));
            List<PerformanceSpecificationDataModel> list = new List<PerformanceSpecificationDataModel>();
            foreach (var line in lines)
            {
                string[] dataValues = line.Split(sep.ToCharArray());
                   PerformanceSpecificationDataModel PerfSpecDataModel = new PerformanceSpecificationDataModel
                   { 
                        Time = dataValues[0], Severity = dataValues[1],
                        Application = dataValues[2], PerfReqId = dataValues[3],
                        Description = dataValues[4], ActualValue = dataValues[5],
                        ValidationValue = dataValues[6] , Validation = new Uri(dataValues[7],UriKind.RelativeOrAbsolute)
                    };

                    list.Add(PerfSpecDataModel);
            }
            return list;
        }
    }
}
