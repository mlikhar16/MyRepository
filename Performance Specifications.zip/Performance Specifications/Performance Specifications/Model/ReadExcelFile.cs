﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Performance_Specifications.Model
{
    public class ReadExcelFile: INotifyPropertyChanged
    {
        private string filepath;
        private string fileExt;

        public string FilePath
        {
            get { return this.filepath; }
            set
            {
                this.filepath = value;
                NotifyPropertyChange();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChange([CallerMemberName] string property = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }
        public ReadExcelFile(string filepath,string fileExt)
        {
            this.filepath = filepath;
            this.fileExt = fileExt;
        }

        public DataTable ReadExcel()
        {
            string conn = string.Empty;
            DataTable dtexcel = new DataTable();
            if (fileExt.CompareTo(".xls") == 0)
                conn = @"provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filepath + ";Extended Properties='Excel 8.0;HRD=Yes;IMEX=1';"; //for below excel 2007  
            else
                conn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filepath + ";Extended Properties='Excel 12.0;HDR=NO';"; //for above excel 2007  
            using (OleDbConnection con = new OleDbConnection(conn))
            {
                try
                {
                    OleDbDataAdapter oleAdpt =
                        new OleDbDataAdapter(String.Format("select * from [{0}$]", Constants.sheet),
                            con);  
                    oleAdpt.Fill(dtexcel);  
                }
                catch
                {
                    MessageBoxResult result = MessageBox.Show("Sheet name must be 'PerformanceSpecifications'", "Alert",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            return dtexcel;
        }
    }
}
