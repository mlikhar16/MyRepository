﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Server;

namespace Performance_Specifications.Model
{
    public class ValidationFile:IPowerShellCommand,INotifyPropertyChanged
    {
        private string filepath;
        private string processId;

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChange([CallerMemberName] string property = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public string FilePath
        {
            get { return this.filepath; }
            set { this.filepath = value; NotifyPropertyChange(); }
        }
        public ValidationFile()
        {
            this.filepath = "Select a Validation File";
        }

        public ValidationFile(string filepath)
        {
            this.filepath = filepath;
        }
        public ValidationFile(string filepath, string processId)
        {
            this.filepath = filepath;
            this.processId = processId;
        }

        public Collection<PSObject> RunPowerShellCommand()
        {
            Runspace runspace = RunspaceFactory.CreateRunspace();
            runspace.Open();
            Pipeline pipeline = runspace.CreatePipeline();
            string commandtext = String.Format("Get-Content -Path \"{0}\" | Where-Object {{$_ -like '*{1},*'}}"
                , filepath, processId);
            pipeline.Commands.AddScript(commandtext);
            Collection<PSObject> psObjs = pipeline.Invoke();
            return psObjs;
        }

        public string GetValidationValue()
        {
            Collection<PSObject> psObjs = RunPowerShellCommand();
            if (psObjs.Count == 0)
                return Constants.NotApplicable;
            return psObjs[0].BaseObject.ToString().Split(',')[psObjs[0].BaseObject.ToString().Split(',').Length - 1];
        }
    }
}
