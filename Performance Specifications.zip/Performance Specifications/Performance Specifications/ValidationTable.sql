﻿CREATE TABLE [dbo].[ValidationTable]
(
	[RequirementId] NVARCHAR(MAX) NOT NULL PRIMARY KEY, 
    [ValidationValue] REAL NULL
)
