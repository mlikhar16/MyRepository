﻿using Performance_Specifications.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using DataTable = System.Data.DataTable;

namespace Performance_Specifications.ViewModel
{
    public class InsertDataInDB
    {
        private SplitAndArrange split;
        public InsertDataInDB(SplitAndArrange split)
        {
            this.split = split;
        }

        public void ExecuteInsertCommand()
        {
            bool flag = false;
            if (CheckForDuplicateWithoutValidtion())
            {
                if (!CheckForDuplicateWithValidtion())
                {
                    string sql_update = "UPDATE PerformanceSpecificationMainTable SET [ValidationValue] = '" +
                                        split.ValidationValueInFloat + "', [ValidationValueText] = '" +
                                        split.DataModel.ValidationValue +
                                        "', [Validation] = '" + split.DataModel.Validation + "' WHERE [Date] = '" +
                                        split.Date +
                                        "' AND [Time] = '" + split.DataModel.Time + "' AND [Application] = '" +
                                        split.DataModel.Application +
                                        "' AND [RequirementId] = '" + split.DataModel.PerfReqId + "';";
                    SQLCommands.ExecuteSQL(sql_update);
                }
            }
            else
                flag = true;

            if (flag)
            {
                string sql_Add =
                    "INSERT INTO PerformanceSpecificationMainTable ([Date],[Time],[Severity],[Application],[RequirementId],[Description],[ActualValue],[ActualValueText],[ValidationValue],[ValidationValueText],[Validation],[ValidationText]) VALUES('" +
                    split.Date + "','" + split.DataModel.Time + "','" + split.DataModel.Severity + "','" +
                    split.DataModel.Application + "','" + split.DataModel.PerfReqId + "','" +
                    split.DataModel.Description + "','" + split.ActualValueInFloat + "','" +
                    split.DataModel.ActualValue + "','" + split.ValidationValueInFloat + "','" +
                    split.DataModel.ValidationValue + "','" + split.DataModel.Validation + "','" + split.ValidationText + "')";
                SQLCommands.ExecuteSQL(sql_Add);

            }
        }

        private bool CheckForDuplicateWithoutValidtion()
        {
            string sql_select = "SELECT * FROM PerformanceSpecificationMainTable WHERE [Date] = '" + split.Date +
                                "' AND [Time] = '" + split.DataModel.Time + "' AND [Application] = '" +
                                split.DataModel.Application + "' AND [RequirementId] = '" + split.DataModel.PerfReqId + "' AND [ActualValueText] = '" + split.DataModel.ActualValue + "';";
            
            //string sql_select = "SELECT * FROM PerformanceSpecificationMainTable";
            DataTable dt = SQLCommands.GetDataTable(sql_select);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private bool CheckForDuplicateWithValidtion()
        {
            string sql_select = "SELECT * FROM PerformanceSpecificationMainTable WHERE [Date] = '" + split.Date +
                                "' AND [Time] = '" + split.DataModel.Time + "' AND [Application] = '" +
                                split.DataModel.Application + "' AND [RequirementId] = '" + split.DataModel.PerfReqId +
                                "' AND [Validation] = '" + split.DataModel.Validation + "';";
            DataTable dt = SQLCommands.GetDataTable(sql_select);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

    }
}
