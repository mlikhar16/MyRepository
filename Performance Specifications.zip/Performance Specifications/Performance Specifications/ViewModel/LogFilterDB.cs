﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Performance_Specifications.Model;

namespace Performance_Specifications.ViewModel
{
    class LogFilterDB
    {
        private string applicationFilterComboBox;
        private string validationFilterComboBox;
        private string date;
        private string searchString;

        public LogFilterDB(string applicationFilterComboBox, string validationFilterComboBox, string date)
        {
            this.applicationFilterComboBox = applicationFilterComboBox;
            this.validationFilterComboBox = validationFilterComboBox;
            this.date = date;
        }

        public LogFilterDB(string searchString, string date)
        {
            this.searchString = searchString;
            this.date = date;
        }

        public DataTable FilterBasic()
        {
            string sql_select = String.Empty;
            if (applicationFilterComboBox == "All" && validationFilterComboBox == "All")
                sql_select = "SELECT * FROM PerformanceSpecificationMainTable WHERE [Date] LIKE '" + this.date + "';";
            else if(applicationFilterComboBox != "All" && validationFilterComboBox == "All")
                sql_select = "SELECT * FROM PerformanceSpecificationMainTable WHERE [Date] LIKE '" + this.date + "' AND [Application] = '" +
                             applicationFilterComboBox + "';";
            else if(applicationFilterComboBox == "All" && validationFilterComboBox != "All")
                sql_select = "SELECT * FROM PerformanceSpecificationMainTable WHERE [Date] LIKE '" + this.date + "' AND [ValidationText] = '"
                             + validationFilterComboBox + "';";
            else
                sql_select = "SELECT * FROM PerformanceSpecificationMainTable WHERE [Date] LIKE '" + this.date + "' AND [Application] = '" +
                             applicationFilterComboBox + "' AND [ValidationText] = '" + validationFilterComboBox + "';";
            DataTable tb = SQLCommands.GetDataTable(sql_select);
            return tb;
        }

        public DataTable FilterSearch()
        {
            if (searchString != null)
            {
                string sql_select = String.Empty;
                sql_select =
                    "SELECT * FROM PerformanceSpecificationMainTable WHERE [Application] COLLATE Latin1_General_CI_AI LIKE '%" +
                    this.searchString + "%' OR [Description] COLLATE Latin1_General_CI_AI LIKE '%" + this.searchString +
                    "%' OR [RequirementId] COLLATE Latin1_General_CI_AI LIKE '%" + this.searchString + "%' AND [Date] = '" +
                    this.date + "';";
                DataTable tb = SQLCommands.GetDataTable(sql_select);
                return tb;
            }
            else
            {
                return new DataTable();
            }
        }
    }
}
