﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.ViewModel
{
    class LogFilterDB
    {
        private string applicationFilterComboBox;
        private string validationFilterComboBox;
        private List<string> applicationFilterList;
        private List<string> reqIDFilterList;
        private List<string> customSearchList;

        public LogFilterDB(string applicationFilterComboBox, string validationFilterComboBox)
        {
            this.applicationFilterComboBox = applicationFilterComboBox;
            this.validationFilterComboBox = validationFilterComboBox;
        }

        public void FilterBasic()
        {
            string sql_select = String.Empty;
            if (applicationFilterComboBox == "All" && validationFilterComboBox == "All")
                sql_select = "SELECT * FROM PerformanceSpecificationMainTable;";
            else if(applicationFilterComboBox != "All" && validationFilterComboBox == "All")
                sql_select = "SELECT * FROM PerformanceSpecificationMainTable WHERE [Application] = '" +
                             applicationFilterComboBox + "';";
            else if(applicationFilterComboBox == "All" && validationFilterComboBox != "All")
                sql_select = "SELECT * FROM PerformanceSpecificationMainTable WHERE [ValidationText] = '" 
                             + validationFilterComboBox + "';";
            else
                sql_select = "SELECT * FROM PerformanceSpecificationMainTable WHERE [Application] = '" +
                             applicationFilterComboBox + "' AND [ValidationText] = '" + validationFilterComboBox + "';";
            
        }
    }
}
