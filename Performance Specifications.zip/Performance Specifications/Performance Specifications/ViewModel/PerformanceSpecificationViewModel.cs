﻿using Performance_Specifications.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Performance_Specifications.ViewModel
{
    public class PerformanceSpecificationViewModel: INotifyPropertyChanged
    {
        private ICommand browseValidationFile;
        private ICommand browseLogFile;
        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChange([CallerMemberName] string property="")
        {
            if(PropertyChanged!=null)
                PropertyChanged(this,new PropertyChangedEventArgs(property));
        }

        private ReadExcelFile validationExcelFile;
        public ReadExcelFile ValidationExcelFile
        {
            get
            {
                return this.validationExcelFile;
            }
            set
            {
                this.validationExcelFile = value;
                NotifyPropertyChange();
            }

        }

        private ValidationFile validationFile;
        public ValidationFile ValidationFile
        {
            get
            {
                if (this.validationFile == null)
                    this.validationFile = new ValidationFile();
                return this.validationFile;
            }
            set
            {
                this.validationFile = value;
                NotifyPropertyChange();
            }

        }

        private ReadRawLogFile rawfile;
        public ReadRawLogFile RawFile
        {
            get
            {
                if(this.rawfile==null)
                    this.rawfile = new ReadRawLogFile();
                return this.rawfile;
            }
            set
            {
                this.rawfile = value;
                NotifyPropertyChange();
            }

        }

        private ReadFilteredLogFile filteredfile;

        public ReadFilteredLogFile FilteredFile
        {
            get { return this.filteredfile; }
            set
            {
                this.filteredfile = value;
                NotifyPropertyChange();
            }
        }

        private string selectedApplictionValue;
        public string SelectedApplicationValue
        {
            get
            { return this.selectedApplictionValue; }
            set
            { this.selectedApplictionValue = value; NotifyPropertyChange(); }
        }

        private ComboBoxItem selectedValidationValue;
        public ComboBoxItem SelectedValidationValue
        {
            get
            { return this.selectedValidationValue; }
            set
            { this.selectedValidationValue = value; NotifyPropertyChange(); }
        }

        private VirtualizingCollection<PerformanceSpecificationDataModel> avCollection;
        public VirtualizingCollection<PerformanceSpecificationDataModel> AVCollection
        {
            get { return this.avCollection; }
            set { this.avCollection = value; NotifyPropertyChange(); }
        }

        private PerformanceSpecificationDataProvider dataProvider;
        public PerformanceSpecificationDataProvider DataProvider
        {
            get { return this.dataProvider; }
            set { this.dataProvider = value; NotifyPropertyChange(); }
        }

        private Visibility isLoading = Visibility.Hidden;
        public Visibility IsLoading
        {
            get { return this.isLoading; }
            set { this.isLoading = value; NotifyPropertyChange(); }
        }

        private static void ThrowErrorandRestart()
        {
            MessageBoxResult result = MessageBox.Show("Invaid Log File selected\nPlease Select appropriate log file", "Alert",
                MessageBoxButton.OK, MessageBoxImage.Error);
            if (result == MessageBoxResult.OK)
            {
                Process.Start(Application.ResourceAssembly.Location);
                Environment.Exit(Environment.ExitCode);
            }
        }

        private static void ValidateLogFile(string filepath)
        {
            string sep = "\t";
            try
            {
                string logValidationValue = System.IO.File.ReadLines(filepath).Skip(0).Take(1)
                    .First().Split(sep.ToCharArray())[5].ToLower();
                if (!logValidationValue.Contains(Constants.logValidationString.ToLower()))
                    ThrowErrorandRestart();
            }
            catch (Exception e)
            {
                ThrowErrorandRestart();
            }
        }

        private static Microsoft.Win32.OpenFileDialog SelectFileDialog(string filextension, string filter)
        {
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
            openFileDlg.DefaultExt = filextension;
            openFileDlg.Filter = filter;
            openFileDlg.InitialDirectory = Constants.BaseDir;
            return openFileDlg;
        }

        public ICommand BrowseValidationExcelFile
        {
            get
            {
                if (browseValidationFile == null)
                    browseValidationFile = new Commands(BrowseValidationExcelFileCommand, CanExecBrowseValidationExcelFileCommand);
                return browseValidationFile;
            }
        }

        private void BrowseValidationExcelFileCommand(object arg)
        {
            Microsoft.Win32.OpenFileDialog openFileDlg = SelectFileDialog(Constants.excelextension, Constants.excelfilter);
            bool? result = openFileDlg.ShowDialog();
            if (result == true)
            {
                string fileExt = Path.GetExtension(openFileDlg.FileName);
                ValidationExcelFile = new ReadExcelFile(openFileDlg.FileName, fileExt);
                if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                {
                    try
                    {
                        DataTable dtExcel = new DataTable();
                        dtExcel = ValidationExcelFile.ReadExcel();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Please choose .xls or .xlsx file only.", "Warning", MessageBoxButton.OK, MessageBoxImage.Error); //custom messageBox to show error  
                }
            }

        }
        private bool CanExecBrowseValidationExcelFileCommand(object arg)
        {
            return true;
        }

        private string GetValidationTextFromComboBox()
        {
            StackPanel sp = (StackPanel)SelectedValidationValue.Content;
            TextBlock t = (TextBlock)sp.Children[1];
            return t.Text;
        }

        public ICommand BrowseValidationFile
        {
            get
            {
                if (browseValidationFile == null)
                    browseValidationFile = new Commands(BrowseValidationFileCommand, CanExecBrowseValidationFileCommand);
                return browseValidationFile;
            }
        }
      
        private void BrowseValidationFileCommand(object arg)
        {
            //string trunc = "TRUNCATE TABLE PerformanceSpecificationMainTable";
            //SQLCommands.ExecuteSQL(trunc);
            Microsoft.Win32.OpenFileDialog openFileDlg = SelectFileDialog(Constants.csvextension, Constants.csvfilter);
            bool? result = openFileDlg.ShowDialog();
            if (result == true)
                ValidationFile = new ValidationFile(openFileDlg.FileName);
        }

   
        private bool CanExecBrowseValidationFileCommand(object arg)
        {
            return true;
        }
        public ICommand BrowseLogFile
        {
            get
            {
                if (browseLogFile == null)
                    browseLogFile = new Commands(BrowseLogFileCommand, CanExecBrowseLogFileCommand);
                return browseLogFile;
            }
        }

         private bool CanExecBrowseLogFileCommand(object arg)
        {
            return true;
        }

        private void BrowseLogFileCommand(object obj)
        {
            Microsoft.Win32.OpenFileDialog openFileDlg = SelectFileDialog(Constants.logextension, Constants.logfilter);
            bool? result = openFileDlg.ShowDialog();
            ValidateLogFile(openFileDlg.FileName);
            SelectedApplicationValue = "All";
            if (result == true)
            { 
                RawFile = new ReadRawLogFile(openFileDlg.FileName);
                this.PropertyChanged += OnSelectedValueChange;
                IsLoading = Visibility.Visible;
                var t = Task.Factory.StartNew(() => RawFile.ReadAndFilter()).ContinueWith((task) =>
                {
                    FilteredFile = new ReadFilteredLogFile(RawFile,ValidationFile);
                    FilteredFile.PropertyChanged += PropertyChangedCount;
                    FilteredFile.ReadAndFilter();
                });
            }
        }
        void PropertyChangedCount(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Count")
            {
                PopulateTable(FilteredFile.Count);
            }
        }

        void PopulateTable(int Count)
        {
            if (Count == Math.Min(FilteredFile.TotalEntries,1000))
            {
                IsLoading = Visibility.Hidden;
                DataProvider = new PerformanceSpecificationDataProvider(FilteredFile.Count,1000, FilteredFile.DF.OutputFilePath);
                AVCollection = new VirtualizingCollection<PerformanceSpecificationDataModel>(DataProvider,100,30000);
            }
        }

        private void OnSelectedValueChange(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "SelectedApplicationValue" || e.PropertyName == "SelectedValidationValue")
            {
                int lineCount = System.IO.File.ReadLines(FilteredFile.ApplicationListPath[SelectedApplicationValue]).Count();
                DataProvider = new PerformanceSpecificationDataProvider(lineCount, 1000, FilteredFile.ApplicationListPath[SelectedApplicationValue]);
                AVCollection = new VirtualizingCollection<PerformanceSpecificationDataModel>(DataProvider, 100, 30000);
            }
        }
    }
    
}
