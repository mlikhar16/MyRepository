﻿using Microsoft.Win32;
using Performance_Specifications.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Performance_Specifications.ViewModel
{
    public class PerformanceSpecificationViewModel: INotifyPropertyChanged
    {
        private ICommand browseValidationFile;
        private ICommand saveExcelFile;
        private ICommand browseLogFile;
        private ICommand search;
        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChange([CallerMemberName] string property="")
        {
            if(PropertyChanged!=null)
                PropertyChanged(this,new PropertyChangedEventArgs(property));
        }

        private string searchString = "";
        public string SearchString
        {
            get { return this.searchString; }
            set { this.searchString = value; NotifyPropertyChange(); }
        }

        private DataTable currentTable;
        public DataTable CurrentTable
        {
            get { return this.currentTable; }
            set { this.currentTable = value; NotifyPropertyChange(); }
        }

        private ReadExcelFile validationExcelFile;
        public ReadExcelFile ValidationExcelFile
        {
            get
            {
                return this.validationExcelFile;
            }
            set
            {
                this.validationExcelFile = value;
                NotifyPropertyChange();
            }

        }

        private ValidationFile validationFile;
        public ValidationFile ValidationFile
        {
            get
            {
                if (this.validationFile == null)
                    this.validationFile = new ValidationFile();
                return this.validationFile;
            }
            set
            {
                this.validationFile = value;
                NotifyPropertyChange();
            }

        }

        private ReadRawLogFile rawfile;
        public ReadRawLogFile RawFile
        {
            get
            {
                if(this.rawfile==null)
                    this.rawfile = new ReadRawLogFile();
                return this.rawfile;
            }
            set
            {
                this.rawfile = value;
                NotifyPropertyChange();
            }

        }

        private ReadFilteredLogFile filteredfile;

        public ReadFilteredLogFile FilteredFile
        {
            get { return this.filteredfile; }
            set
            {
                this.filteredfile = value;
                NotifyPropertyChange();
            }
        }

        private string selectedApplictionValue;
        public string SelectedApplicationValue
        {
            get
            { return this.selectedApplictionValue; }
            set
            { this.selectedApplictionValue = value; NotifyPropertyChange(); }
        }

        private ComboBoxItem selectedValidationValue;
        public ComboBoxItem SelectedValidationValue
        {
            get
            { return this.selectedValidationValue; }
            set
            { this.selectedValidationValue = value; NotifyPropertyChange(); }
        }

        private VirtualizingCollection<PerformanceSpecificationDataModel> avCollection;
        public VirtualizingCollection<PerformanceSpecificationDataModel> AVCollection
        {
            get { return this.avCollection; }
            set { this.avCollection = value; NotifyPropertyChange(); }
        }

        private PerformanceSpecificationDataProvider dataProvider;
        public PerformanceSpecificationDataProvider DataProvider
        {
            get { return this.dataProvider; }
            set { this.dataProvider = value; NotifyPropertyChange(); }
        }

        private Visibility isLoading = Visibility.Hidden;
        public Visibility IsLoading
        {
            get { return this.isLoading; }
            set { this.isLoading = value; NotifyPropertyChange(); }
        }

        private Visibility searchBar = Visibility.Hidden;
        public Visibility SearchBar
        {
            get { return this.searchBar; }
            set { this.searchBar = value; NotifyPropertyChange(); }
        }

        private static void ThrowErrorandRestart()
        {
            MessageBoxResult result = MessageBox.Show("Invaid Log File selected\nPlease Select appropriate log file", "Alert",
                MessageBoxButton.OK, MessageBoxImage.Error);
            if (result == MessageBoxResult.OK)
            {
                Process.Start(Application.ResourceAssembly.Location);
                Environment.Exit(Environment.ExitCode);
            }
        }

        private static void ValidateLogFile(string filepath)
        {
            string sep = "\t";
            try
            {
                string logValidationValue = System.IO.File.ReadLines(filepath).Skip(0).Take(1)
                    .First().Split(sep.ToCharArray())[5].ToLower();
                if (!logValidationValue.Contains(Constants.logValidationString.ToLower()))
                    ThrowErrorandRestart();
            }
            catch (Exception e)
            {
                ThrowErrorandRestart();
            }
        }

        private static Microsoft.Win32.OpenFileDialog SelectFileDialog(string filextension, string filter)
        {
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();
            openFileDlg.DefaultExt = filextension;
            openFileDlg.Filter = filter;
            openFileDlg.InitialDirectory = Constants.BaseDir;
            return openFileDlg;
        }

        public ICommand Search
        {
            get
            {
                if (search == null)
                    search = new Commands(SearchCommand, CanExecSearchCommand);
                return search;
            }
        }

        private bool CanExecSearchCommand(object arg)
        {
            return true;
        }

        private void SearchCommand(object obj)
        {
           LogFilterDB db = new LogFilterDB(searchString,RawFile.DF.Date);
           CurrentTable = db.FilterSearch();
           if (CurrentTable.Rows.Count > 0)
           {
               DataProvider = new PerformanceSpecificationDataProvider(CurrentTable.Rows.Count, 1000,
                   ConvertToList());
               AVCollection = new VirtualizingCollection<PerformanceSpecificationDataModel>(DataProvider, 100, 30000);
           }
        }

        public ICommand SaveExcelFile
        {
            get
            {
                if (saveExcelFile == null)
                    saveExcelFile = new Commands(SaveExcelFileCommand, CanExecSaveExcelFileCommand);
                return saveExcelFile;
            }
        }

        private bool CanExecSaveExcelFileCommand(object arg)
        {
            return true;
        }

        private void SaveExcelFileCommand(object obj)
        {
            if (CurrentTable.Rows.Count > 0)
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "Execl files (*.xlsx)|*.xlsx";
                saveFileDialog.FilterIndex = 0;
                saveFileDialog.RestoreDirectory = true;
                saveFileDialog.CreatePrompt = true;
                saveFileDialog.Title = "Export Excel File To";

                Microsoft.Office.Interop.Excel.Application excel;
                Microsoft.Office.Interop.Excel.Workbook excelworkBook;
                Microsoft.Office.Interop.Excel.Worksheet excelSheet;

                bool? result = saveFileDialog.ShowDialog();
                if (result == true)
                {
                    try
                    {
                        //  get Application object.
                        excel = new Microsoft.Office.Interop.Excel.Application();
                        excel.Visible = false;
                        excel.DisplayAlerts = false;

                        // Creation a new Workbook
                        excelworkBook = excel.Workbooks.Add(Type.Missing);

                        // Workk sheet
                        excelSheet = (Microsoft.Office.Interop.Excel.Worksheet) excelworkBook.ActiveSheet;
                        excelSheet.Name = "Sheet1";

                        // loop through each row and add values to our sheet
                        int rowcount = 1;

                        foreach (DataRow datarow in CurrentTable.Rows)
                        {
                            rowcount += 1;
                            for (int i = 1; i <= CurrentTable.Columns.Count; i++)
                            {
                                // on the first iteration we add the column headers
                                if (rowcount == 3)
                                {
                                    excelSheet.Cells[2, i] = CurrentTable.Columns[i - 1].ColumnName;
                                }

                                // Filling the excel file 
                                excelSheet.Cells[rowcount, i] = datarow[i - 1].ToString();
                            }
                        }

                        //now save the workbook and exit Excel
                        excelworkBook.SaveAs(saveFileDialog.FileName);
                        excelworkBook.Close();
                        excel.Quit();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        excelSheet = null;
                        excelworkBook = null;
                    }
                }
            }
        }

        public ICommand BrowseValidationExcelFile
        {
            get
            {
                if (browseValidationFile == null)
                    browseValidationFile = new Commands(BrowseValidationExcelFileCommand, CanExecBrowseValidationExcelFileCommand);
                return browseValidationFile;
            }
        }

        private void BrowseValidationExcelFileCommand(object arg)
        {
            Microsoft.Win32.OpenFileDialog openFileDlg = SelectFileDialog(Constants.excelextension, Constants.excelfilter);
            bool? result = openFileDlg.ShowDialog();
            if (result == true)
            {
                string fileExt = Path.GetExtension(openFileDlg.FileName);
                ValidationExcelFile = new ReadExcelFile(openFileDlg.FileName, fileExt);
                if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
                {
                    try
                    {
                        DataTable dtExcel = new DataTable();
                        dtExcel = ValidationExcelFile.ReadExcel();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Please choose .xls or .xlsx file only.", "Warning", MessageBoxButton.OK, MessageBoxImage.Error); //custom messageBox to show error  
                }
            }

        }
        private bool CanExecBrowseValidationExcelFileCommand(object arg)
        {
            return true;
        }

        private static string GetValidationTextFromComboBox(ComboBoxItem Item)
        {
                StackPanel sp = (StackPanel)Item.Content;
                TextBlock t = (TextBlock)sp.Children[1];
                return t.Text;
        }

        public ICommand BrowseValidationFile
        {
            get
            {
                if (browseValidationFile == null)
                    browseValidationFile = new Commands(BrowseValidationFileCommand, CanExecBrowseValidationFileCommand);
                return browseValidationFile;
            }
        }
      
        private void BrowseValidationFileCommand(object arg)
        {
            //string trunc = "TRUNCATE TABLE PerformanceSpecificationMainTable";
            //SQLCommands.ExecuteSQL(trunc);
            Microsoft.Win32.OpenFileDialog openFileDlg = SelectFileDialog(Constants.csvextension, Constants.csvfilter);
            bool? result = openFileDlg.ShowDialog();
            if (result == true)
                ValidationFile = new ValidationFile(openFileDlg.FileName);
        }

   
        private bool CanExecBrowseValidationFileCommand(object arg)
        {
            return true;
        }
        public ICommand BrowseLogFile
        {
            get
            {
                if (browseLogFile == null)
                    browseLogFile = new Commands(BrowseLogFileCommand, CanExecBrowseLogFileCommand);
                return browseLogFile;
            }
        }

         private bool CanExecBrowseLogFileCommand(object arg)
        {
            return true;
        }

        private void BrowseLogFileCommand(object obj)
        {
            Microsoft.Win32.OpenFileDialog openFileDlg = SelectFileDialog(Constants.logextension, Constants.logfilter);
            bool? result = openFileDlg.ShowDialog();
            ValidateLogFile(openFileDlg.FileName);
            SelectedApplicationValue = "All";
            if (result == true)
            { 
                RawFile = new ReadRawLogFile(openFileDlg.FileName);
                this.PropertyChanged += OnSelectedValueChange;
                IsLoading = Visibility.Visible;
                SearchBar = Visibility.Hidden;
                var t = Task.Factory.StartNew(() => RawFile.ReadAndFilter()).ContinueWith((task) =>
                {
                    FilteredFile = new ReadFilteredLogFile(RawFile,ValidationFile);
                    FilteredFile.PropertyChanged += PropertyChangedCount;
                    FilteredFile.ReadAndFilter();
                });
            }
        }
        void PropertyChangedCount(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Count")
            {
                PopulateTable(FilteredFile.Count);
            }
        }

        private void GetDBTable()
        {
            LogFilterDB db = new LogFilterDB(SelectedApplicationValue, GetValidationTextFromComboBox(SelectedValidationValue),RawFile.DF.Date);
            CurrentTable = db.FilterBasic();
        }

        void PopulateTable(int Count)
        {
            if (Count == FilteredFile.TotalEntries)
            {
                IsLoading = Visibility.Hidden;
                SearchBar = Visibility.Visible;
                LogFilterDB db = new LogFilterDB("All", "All", RawFile.DF.Date);
                CurrentTable = db.FilterBasic();
                if (CurrentTable.Rows.Count > 0)
                {
                    DataProvider =new PerformanceSpecificationDataProvider(CurrentTable.Rows.Count, 1000,
                            ConvertToList());
                    AVCollection =new VirtualizingCollection<PerformanceSpecificationDataModel>(DataProvider, 100, 30000);
                }
                else
                {
                    DataProvider = new PerformanceSpecificationDataProvider(FilteredFile.Count, 1000,
                        FilteredFile.DF.OutputFilePath);
                    AVCollection = new VirtualizingCollection<PerformanceSpecificationDataModel>(DataProvider, 100, 30000);
                }
            }
        }

        private IEnumerable<PerformanceSpecificationDataModel> ConvertToList()
        {
            foreach (DataRow row in CurrentTable.Rows)
            {
                yield return new PerformanceSpecificationDataModel
                {
                    Time = row["Time"].ToString(),
                    Severity = row["Severity"].ToString(),
                    Application = row["Application"].ToString(),
                    PerfReqId = row["RequirementId"].ToString(),
                    Description = row["Description"].ToString(),
                    ActualValue = row["ActualValueText"].ToString(),
                    ValidationValue = row["ValidationValueText"].ToString(),
                    Validation = new Uri(row["Validation"].ToString(), UriKind.RelativeOrAbsolute)
                };
            }
        }

        private void OnSelectedValueChange(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "SelectedApplicationValue" || e.PropertyName == "SelectedValidationValue" || e.PropertyName=="SearchString")
            {
                if (SearchString.Length == 0)
                {
                    GetDBTable();
                    int lineCount = CurrentTable.Rows.Count;
                    DataProvider = new PerformanceSpecificationDataProvider(lineCount, 1000, ConvertToList());
                    AVCollection =
                        new VirtualizingCollection<PerformanceSpecificationDataModel>(DataProvider, 100, 30000);
                    /*int lineCount = System.IO.File.ReadLines(FilteredFile.ApplicationListPath[SelectedApplicationValue]).Count();
                    DataProvider = new PerformanceSpecificationDataProvider(lineCount, 1000, FilteredFile.ApplicationListPath[SelectedApplicationValue]);
                    AVCollection = new VirtualizingCollection<PerformanceSpecificationDataModel>(DataProvider, 100, 30000);*/
                }
            }
        }
    }
    
}
