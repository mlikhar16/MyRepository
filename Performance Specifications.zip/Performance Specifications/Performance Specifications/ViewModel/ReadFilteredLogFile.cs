﻿using Performance_Specifications.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Net.Mime;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Performance_Specifications.ViewModel
{
    public class ReadFilteredLogFile:INotifyPropertyChanged
    {
        private string filepath;
        private int count = 0;
        private int totalEntries;
        private DirectoryAndFiles df;
        private ReadRawLogFile rawfile;
        private ValidationFile validationFile;
        private string date;
        public static Object Lock = new Object();
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChange([CallerMemberName] string property = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public ReadRawLogFile RawFile
        {
            get
            { return this.rawfile; }
            set
            {
                this.rawfile = value;
                NotifyPropertyChange();
            }
        }

        public ValidationFile ValidationFile
        {
            get
            { return this.validationFile; }
            set
            {
                this.validationFile = value;
                NotifyPropertyChange();
            }
        }
        public int TotalEntries
        {
            get { return this.totalEntries; }
            set
            {
                this.totalEntries = value;
                NotifyPropertyChange();
            }
        }
        public DirectoryAndFiles DF
        {
            get { return this.df; }
            set
            {
                this.df = value;
                NotifyPropertyChange();
            }
        }

        public string FilePath
        {
            get { return this.filepath; }
            set
            {
                this.filepath = value;
                NotifyPropertyChange();
            }
        }

        public int Count
        {
            get { return this.count; }
            set
            {
                this.count = value;
                NotifyPropertyChange();
            }
        }
 
        public string Date
        {
            get { return this.date; }
            set
            {
                this.date = value;
                NotifyPropertyChange();
            }
        }

        private IDictionary<string, string> applicationListPath = new Dictionary<string, string>();
        public IDictionary<string, string> ApplicationListPath
        {
            get { return this.applicationListPath; }
            set
            {
                this.applicationListPath = value;
                NotifyPropertyChange();
            }
        }

        private List<string> applicationList = new List<string>();
        public List<string> ApplicationList
        {
            get { return this.applicationList; }
            set
            {
                this.applicationList = value;
                NotifyPropertyChange();
            }
        }
        public ReadFilteredLogFile(ReadRawLogFile rawfile, ValidationFile validationFile)
        {
            this.rawfile = rawfile;
            this.validationFile = validationFile;
            this.filepath = RawFile.DF.OutputFilePath;
            TotalEntries = System.IO.File.ReadLines(filepath).Count();
            this.df = new DirectoryAndFiles(filepath,"Structured",RawFile.DF.DirectoryName,
                                                         RawFile.DF.InputFileName,RawFile.DF.Date);
            ApplicationListPath.Add(new KeyValuePair<string, string>("All",DF.OutputFilePath));
        }

        private void GetApplicationListPath(SplitAndArrange split)
        {
            ApplicationFiles application = new ApplicationFiles(split,DF.DirectoryName);
            application.StoreApplicationRecord();
            ApplicationListPath[application._Application] = application.FilePath;
        }

        private void BuildStructureFile(string line)
        {
            try
            {
                    SplitAndArrange split = new SplitAndArrange(line,ValidationFile.FilePath);
                    split.SplitDataValues();
                    InsertDataInDB insertData = new InsertDataInDB(split);
                    insertData.ExecuteInsertCommand();
                    lock (Lock)
                    {
                        System.IO.File.AppendAllText(DF.OutputFilePath, split.Line + Environment.NewLine);
                    }
                    GetApplicationListPath(split);
                    ApplicationList = ApplicationListPath.Keys.Cast<string>().ToList();
                    Count++;
            }
            catch (Exception e)
            {
                new NotImplementedException();
            }
        }

        private static IEnumerable<string> IterateUntilFalse(StreamReader infile)
        {
            string line;
            while ((line = infile.ReadLine()) != null) yield return line;
        }
        private void WhileInParallel(ParallelOptions parallelOptions,StreamReader infile)
        {
            Parallel.ForEach(IterateUntilFalse(infile), parallelOptions,
                (line) => BuildStructureFile(line));
        }

        private void WhileInSerial(StreamReader infile)
        {
            string line;
            while ((line = infile.ReadLine()) != null)
            {
                BuildStructureFile(line);
            }
        }

        public void ReadAndFilter()
        {
            StreamReader infile = new StreamReader(FilePath);
            //WhileInParallel(new ParallelOptions(), infile);
            WhileInSerial(infile);
            infile.Close();
        }
    }
}
