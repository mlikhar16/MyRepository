﻿using Performance_Specifications.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.ViewModel
{
    public class ReadRawLogFile:INotifyPropertyChanged, IReadLogFile, IPowerShellCommand
    {
        private string filepath;
        private DirectoryAndFiles df;
        private int totalEntries = 0;

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChange([CallerMemberName] string property = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public int TotalEntries
        {
            get { return this.totalEntries; }
            set
            {
                this.totalEntries = value;
                NotifyPropertyChange();
            }
        }

        public DirectoryAndFiles DF
        {
            get { return this.df; }
            set
            {
                this.df = value;
                NotifyPropertyChange();
            }
        }

        public string FilePath
        {
            get { return this.filepath; }
            set
            {
                this.filepath = value;
                NotifyPropertyChange();
            }
        }
        public ReadRawLogFile()
        {
            this.filepath = "Select a Log File";
        }
        public ReadRawLogFile(string filepath)
        {
            this.filepath = filepath;
            this.df = new DirectoryAndFiles(filepath,"Filtered");
            df.CreateDirectory();
            TotalEntries = System.IO.File.ReadLines(filepath).Count();
        }

        
        public void ReadAndFilter()
        {
            RunPowerShellCommand();
        }

        public Collection<PSObject> RunPowerShellCommand()
        {
            Runspace runspace = RunspaceFactory.CreateRunspace();
            runspace.Open();
            Pipeline pipeline = runspace.CreatePipeline();
            string commandtext = String.Format("Get-Content -Path \"{0}\" | Where-Object {{$_ -like '{1}'}} | Out-File -FilePath \"{2}\""
                , FilePath, Constants.filterRegex, DF.OutputFilePath);
            pipeline.Commands.AddScript(commandtext);
            Collection<PSObject> psObj = pipeline.Invoke();
            return psObj;
        }
    }
}
