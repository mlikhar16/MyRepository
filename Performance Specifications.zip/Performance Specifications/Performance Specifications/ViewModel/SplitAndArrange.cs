﻿using Performance_Specifications.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Performance_Specifications.ViewModel
{
    public class SplitAndArrange
    {
        private string rawLine;
        private string validationFileName;
        private float validationValueInFloat;
        private float actualValueInFloat;
        private string validationText;

        public string ValidationText
        {
            get { return this.validationText; }
            set { this.validationText = value; }
        }

        public float ValidationValueInFloat
        {
            get { return this.validationValueInFloat; }
            set { this.validationValueInFloat = value; }
        }

        public float ActualValueInFloat
        {
            get { return this.actualValueInFloat; }
            set { this.actualValueInFloat = value; }
        }
        public SplitAndArrange(string rawLine)
        {
            this.rawLine = rawLine;
        }
        public SplitAndArrange(string rawLine, string validationFileName)
        {
            this.rawLine = rawLine;
            this.validationFileName = validationFileName;
        }
        public PerformanceSpecificationDataModel DataModel { get; set; } = new PerformanceSpecificationDataModel();

        private string line;
        public string Line
        {
            get { return this.line; }
            set { this.line = value; }
        }

        private string date;
        public string Date
        {
            get { return this.date; }
            set { this.date = value; }
        }
        public void SplitDataValues()
        {
            string sep = "\t";
            Line = "";
            string[] splitAllContent = rawLine.Split(sep.ToCharArray());
            string[] splitPerfReqIdandDescription = splitAllContent[splitAllContent.Length - 1].Trim().Split(':');
            string[] extractPerfSpecValuefromDescription = splitPerfReqIdandDescription[splitPerfReqIdandDescription.Length - 1].Trim().Split(' ');
            string Description = "";
            for (int i = 0; i < extractPerfSpecValuefromDescription.Length - 3; i++)
            {
                Description += extractPerfSpecValuefromDescription[i].Trim() + " ";
            }
            Date = splitAllContent[1].Trim();
                DataModel.ActualValue =
                    (extractPerfSpecValuefromDescription[extractPerfSpecValuefromDescription.Length - 2].Trim() + " "
                     + extractPerfSpecValuefromDescription[extractPerfSpecValuefromDescription.Length - 1].Trim()
                    )
                    .Trim();
               
                DataModel.Time = splitAllContent[2].Trim();
                DataModel.Severity = splitAllContent[4].Trim();
                DataModel.Application = splitAllContent[5].Trim();
                DataModel.PerfReqId = splitPerfReqIdandDescription[1].Trim();
                DataModel.Description = Description.Trim();

                ValidationFile validationFile = new ValidationFile(this.validationFileName,DataModel.PerfReqId);
                ValidateProcessMetric metric =
                    new ValidateProcessMetric(DataModel.ActualValue, validationFile.GetValidationValue());


                if (validationFile.GetValidationValue() == Constants.NotApplicable)
                {
                    DataModel.ValidationValue = Constants.NotApplicable;
                    DataModel.Validation = new Uri(Constants.NA, UriKind.RelativeOrAbsolute);
                    ValidationText = Constants.NotApplicable;
                }
                else
                {
                    DataModel.ValidationValue = metric.GetValidationValue().ToString() + " milliseconds";
                    DataModel.Validation = new Uri(metric.Validate(), UriKind.RelativeOrAbsolute);
                    ValidationText = metric.ValidationText;
                }

                ValidationValueInFloat = metric.GetValidationValue();
                ActualValueInFloat = metric.GetActualValue();

            Line += DataModel.Time + "\t" + DataModel.Severity + "\t" +
                        DataModel.Application + "\t" + DataModel.PerfReqId + "\t"
                        + DataModel.Description + "\t" + DataModel.ActualValue + "\t"
                        + DataModel.ValidationValue + "\t" + DataModel.Validation.ToString();
        }

        public void GetDate()
        {
            string sep = "\t";
            string[] splitAllContent = rawLine.Split(sep.ToCharArray());
            Date = splitAllContent[1].Trim();
        }
    }
}
