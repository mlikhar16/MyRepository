﻿using Performance_Specifications.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Performance_Specifications.ViewModel
{
    public class ValidateProcessMetric:ICheckUnit,INotifyPropertyChanged
    {
        private string actualValue;
        private string validationValue;
        private string validationText;

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChange([CallerMemberName] string property = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public string ValidationText
        {
            get { return this.validationText; }
            set { this.validationText = value;NotifyPropertyChange(); }
        }
        public ValidateProcessMetric(string actualValue,string validationValue)
        {
            this.actualValue = actualValue;
            this.validationValue = validationValue;
        }

        public static string ExtractUnit(string metric)
        {
            return Regex.Replace(metric, @"[^A-Za-z]+", String.Empty);
        }

        private static float GetDigitFromSplitArray(string[] digits)
        {
            float result = 0;
            foreach (var digit in digits)
            {
                if (float.TryParse(digit, out result))
                {
                    result = float.Parse(digit);
                    break;
                }
            }
            return result;
        }

        public static float ExtractDigit(string metric)
        {
            string[] digits = Regex.Split(metric, @"[^0-9\.]");
            return GetDigitFromSplitArray(digits);
        }

        private string AbstractValidate(float a, float b)
        {
            if (a <= b)
            {
                ValidationText = Constants.SuccessText;
                return Constants.Success;
            }
            else
            {
                ValidationText = Constants.FailureText;
                return Constants.Failure;
            }
            
        }

        public string Validate()
        {
            if (IsSeconds())
                return AbstractValidate(ExtractDigit(actualValue), ExtractDigit(validationValue) * 1000);
            else if(IsMinutes())
                return AbstractValidate(ExtractDigit(actualValue), ExtractDigit(validationValue) * 60 * 1000);
            else
                return AbstractValidate(ExtractDigit(actualValue), ExtractDigit(validationValue));
        }

        public bool IsMilliSeconds()
        {
            return Constants.milliseconds.Contains(ExtractUnit(validationValue));
        }

        public bool IsSeconds()
        {
            return Constants.seconds.Contains(ExtractUnit(validationValue));
        }

        public bool IsMinutes()
        {
            return Constants.minutes.Contains(ExtractUnit(validationValue));
        }

        public float GetActualValue()
        {
            return ExtractDigit(actualValue);
        }

        public float GetValidationValue()
        {
            if(IsSeconds())
                return ExtractDigit(validationValue)*1000;
            else if (IsMinutes())
                return ExtractDigit(validationValue)*60000;
            else
                return ExtractDigit(validationValue);
        }
    }
}
